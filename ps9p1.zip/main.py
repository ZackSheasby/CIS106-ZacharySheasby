qty = float(input("Enter Quantity"))
price = float(input("Enter Price"))
disrate = float(input("Enter Discount Rate"))

def amount(qty,price,disrate):
  total = float(qty) * float(price)
  disamount = float(total) - float(price)
  disprice = float(total) * float(disrate)

  return total,disamount,disprice

print("Discounted Amount:   ", amount)  
print("Discounted Price:     ",price)