I1 = float(input("Enter amount of Item purchased"))
T1 = float(input("Enter 0.07 as the tax "))

#process phase
A = I1
T= T1
S = I1*T1 +I1

#output
print ("The amount is", A)
print ("The tax is", T)
print ("The total amount with tax is",S)