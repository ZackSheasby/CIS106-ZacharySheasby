discsum = 0
counter = 0.0
response = input("Do you want to Continue? Yes or No?")

while response == "Yes":
  qty = float(input("Enter Quantity"))
  price = float(input("Enter Price"))
  
  extprice = price * qty

  if extprice > 10000:
    discount = extprice * 0.25
  else:
    discount = extprice * 0.10

  total = extprice - discount

  discsum = discsum + discount
  
  counter = counter + 1
 
  print("Extended Price:     ", extprice)
  print("Discount Amount:      ", discount)
  print("New Total:        ", total)



  response = input("Do you want to Continue? Yes or No?")

print("Total Discounts Given:     ", discsum)
avgdisc = discsum / counter
print("Average Discount:     ", avgdisc)   

