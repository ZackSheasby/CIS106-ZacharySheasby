def displaynames(lastn,score):
 l = len(lastn)
 
 for x in range(0,l,1):
   print(x,"   ",lastn[x],"   ", score[x])
 




f = open("lastname.txt", "r")  

lastn = []
score = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()

f.close()

print("Test Scores in Order")
displaynames(lastn,score)
