f = open("data1.txt", "r")

lastname = str(f.readline().rstrip('\n'))

bonusp = 0.0

while lastname != "":
  salary = float(f.readline().rstrip('\n'))

  if salary >= 100000:
    bonusr = 0.20
  elif salary  >= 50000:
    bonusr = 0.15
  else:
    bonusr = .10    

  bonus = bonusr * salary + bonusr
  bonusp = bonusp + bonus

  print("Last Name:  ", lastname)
  print("Salary:   ", salary)
  print("Bonus:  ", bonus)
  print("    ")
  lastname = f.readline()

f.close()  

print("Total Bonuses Paid Out:  ", bonusp)