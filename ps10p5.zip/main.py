def seqsearch(lastn,sname):
  l = len(lastn)
  i = -1
  for y in range (0,l,1):
    if lastn[y] == sname:
      i = y

  return i
 

f = open("lastname.txt", "r")  

lastn = []
score = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()

f.close()

response = input("Do you want to use this Program? Yes or No?")

while response == "Yes":
  sname = input("Enter Last Name of Batter to search for")
  
  i = seqsearch(lastn, sname)
  if i == -1:
    print(sname, "  Name not Found  ")
  else:
    print(lastn[i], "  Batting Average of  ", score[i])  

  response = input("Do you want to use this Program? Yes or No?")  