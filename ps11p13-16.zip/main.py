#dl13
mylist4 = ["Rizzo","Davis","Baez","Happ","Bryant"]
print(mylist4)

#dl14
mylist4.sort()
print(mylist4)

#dl15+16
names = ["Rizzo","Davis","Baez","Happ","Bryant"]
backward_names = names.copy()
backward_names.reverse()
print(names)
print(backward_names)
