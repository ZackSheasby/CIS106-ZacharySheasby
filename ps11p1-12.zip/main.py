#dl1
def dl1(mylist):
  n = int(input("Number of Items for your List"))
  for n in range(0,n,1):
    s = int(input("Enter an Integer"))
    mylist.append(s)
  return mylist
def displaylist(mylist):
 for item in mylist:
   print(item) 

#main
mylist = []
mylist = dl1(mylist)
displaylist(mylist)
print(mylist)

#dl2
mylist.insert(0,99)
print(mylist)

#dl3
mylist[0] = 100
print(mylist)

#dl4
mylist2 = [500,600,700,800,900]
mylist2.extend(mylist)
print(mylist2)

#dl5
mylist2.remove(800)
print(mylist2)

#dl6
mylist2.remove(700)
print(mylist2)

#dl7
mylist3 = ["A", "B", "C", "A", "A", "C"]
print(mylist3)

#dl8
print("Count of the Number of A Grades", mylist3.count("A"))

#dl9
print("Index Position of the First B Grade",mylist3.index("B"))

#dl10
look_for = "F"
if look_for in mylist3:
  print(str(look_for) + "is at index" + str(mylist3.index(look_for)))
else:
  print(str(look_for) + "isn't in the list.")

#d11
mylist2 = [500,600,700,800,900]
mylist2.clear()
print(mylist2)

#d12
mylist2 = [500,600,700,800,900]
del mylist2
print(mylist2)
