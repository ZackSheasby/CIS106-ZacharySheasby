#comment input
P1 =float(input("Enter price of item"))
D1 =float(input("Enter discount percent"))


#process phase
S= P1 * D1
D= P1- P1 * D1 

#output
print("The discount amount is" , S) 
print("The discounted price is ", D)