#inputs
q1 = float(input("Enter quantity per unit"))
p1 = float(input("Enter price per unit"))

#process phase
S = q1 * p1

#output
print ("The extended price is" , S)