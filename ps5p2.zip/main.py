startv = int(input("Enter a Start Value"))
stopv = int(input("Enter a Stop Value"))
incrv = int(input("Enter an Increase Value"))

while startv <= stopv:
  print(startv)
  startv = startv + incrv