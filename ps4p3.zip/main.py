
principle = int(input("Enter an amount of CDs"))

if principle > 100000.00: 
    rate = 0.06
elif principle >= 50000.00 and principle < 100000.00:
    rate = 0.05
elif principle >= 50000.00    and principle <100000.00: 
   rate = 0.04
else:
   rate = 0.02

firstyear = principle * rate 

print ("Principle:     ",principle)
print("Interest Rate:     ", rate)
print("Interest Amount for 1st Year:    ",firstyear)