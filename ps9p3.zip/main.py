lastname = input("Enter Sales Person Last Name")
sales = input("Enter Sales")

def com(sales):
  if sales > 100000:
    com = .10
  else:
    com = .05

  commish = float(sales) * float(com)

  return com  

def nxttar(sales):
  nxttar = float(sales) * 0.5

  return nxttar    

print("Sales Person:    ",lastname)
print("Commision:    ",com)
print("Next Year's Target:   ",nxttar)