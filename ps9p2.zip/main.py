lastname = input("Enter Last Name of Student")
score1 = float(input("Enter Test Score 1"))
score2 = float(input("Enter Test Score 2`"))
score3 = float(input("Enter Test Score 3"))

def avg(score1,score2,score3):
  avg = float(score1) + float(score2) + float(score3) / 3
  
  return avg

def score(score1,score2,score3):
  score = float(score1) + float(score2) + float(score3)

  return score

print("Student Last Name:    ",lastname)
print("Total Points:    ", score)  
print("Average Exam Score:    ", avg)



