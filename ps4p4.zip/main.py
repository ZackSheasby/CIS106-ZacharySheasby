
tic = int(input("Enter the number of concert Tickets"))

if tic >= 25:
  price = 50
elif tic > 10:
  price = 60
elif tic > 9:
  price = 70
else:
  price = 75

total = tic * price

print("Number of Tickets:    ", tic)
print("Price per Ticket:    ", price)
print("The total cost is:    ",total)


