#comment input
G1 = float(input("Enter miles driven"))
G2 = float(input("Enter gallons of gas used"))

#process phase
S= G1/G2

#output
print ("The miles per gallon is", S)