class Student:
  def __init__(self, first, last, district, credits):
    self.first = first
    self.last = last
    self.district = district
    self.credits = credits

  def tuition(self,rate):
    b = float(rate) * float(self.credits)
    return b

empl1 = Student('Zack','Sheasby','I',16.00)

print(empl1.first)
print(empl1.last)
print(empl1.credits)
print(empl1.district)
print(empl1.tuition(250))