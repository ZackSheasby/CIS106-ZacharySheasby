def displaynames(lastn):
 for i in lastn:
    print (i)

  

def displayr(lastn):
  l = len(lastn)
  print("Arrays in Reverse Order")
  for i in range (l-1,-1,-1):
    print(lastn[i])



f = open("lastname.txt", "r")  

lastn = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))

  lastname = f.readline()

f.close()

print("Arrays in Order")
displaynames(lastn)
displayr(lastn)