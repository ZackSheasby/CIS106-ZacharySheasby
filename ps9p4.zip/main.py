lastname = input("Enter Last Name of Bowler")
score1 = float(input("Enter Bowler Score 1"))
score2 = float(input("Enter Bowler Score 2"))
score3 = float(input("Enter Bowler Score 3"))
hand = float(input("Enter Handicap"))

def avgscore(score1,score2,score3):
  avgscore = float(score1) + float(score2) + float(score3) / 3

  return avgscore

def avghand(score1,score2,score3,hand):
  avghand = float(score1) + float(score2) + float(score3) * float(hand)

  return avghand


print("Bowler Last Name:   ", lastname)
print("Average Score:    ", avgscore)
print("Average Score with Handicap:     ", avghand)      