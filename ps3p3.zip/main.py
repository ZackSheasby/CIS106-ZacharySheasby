qty=float(input("Enter number of books"))
cost=float(input("Enter cost per book"))

total= qty * cost 

if total<50:
  up = 25.00
else:  
  up = 0.00

total= qty * cost + up
charge= up

print("Order Total",total )
print("Shipping Charge", charge  )