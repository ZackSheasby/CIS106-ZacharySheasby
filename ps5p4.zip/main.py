counter = 0
totald = 0.0

response = input("Do you want to Compute you Gross Pay? Yes or No")

while response == "Yes":
  counter = counter + 1
  lastname = input("Enter Last Name")
  hours = float(input("Enter Hours Worked"))
  pay = float(input("Enter Pay"))
  grosspay = pay * hours
  totald = totald + grosspay
  print("Last Name:    ", lastname)
  print("Gross Pay:      ", grosspay)
  response = input("Do you want to Compute you Gross Pay? Yes or No")

totaldata = totald / counter  
print("Number of Employees:     ", counter)
print("Average of all the Gross Pays:    ", totaldata)