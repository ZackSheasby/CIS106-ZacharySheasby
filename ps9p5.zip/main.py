qty = float(input("Enter Quantity of an Item"))
price = float(input("Enter Price of Item"))

def comptotal(qty,price):
  total = float(qty) * float(price)

  tax = float(total) * 0.07



  return total,tax

total = comptotal
tax = comptotal  

print("Total:    ", total)
print("Tax:    ", tax)