def hilow(lastn,score):
  l = len(lastn) 
  hiscore = -1
  lowscore = 99999999
  for y in range (0,l,1):
    if float(score[y]) > float (hiscore):
      hiindex = y
      hiscore = score[y]

    if float(score[y]) < float(lowscore):
      loindex = y
      lowscore = score[y]

  print("Highest Score", lastn[hiindex], score[hiindex])  
  print("Lowest Score", lastn[loindex], score[loindex] )   

    
 




f = open("lastname.txt", "r")  

lastname = f.readline()
lastn = []
score = []



while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()

f.close

hilow(lastn, score)