
qty = int(input("Enter quantity of widgets"))

if qty > 10000:
  price = 10.00
elif qty > 5000:
  price = 20.00
elif qty < 5000:
  price = 30.00

extprice = qty * price
tax = 0.07 * extprice
total = extprice + tax

print ("The Extended Price:     ", extprice)
print(" The Tax Amount:     ", tax)
print("The Total:    ", total)