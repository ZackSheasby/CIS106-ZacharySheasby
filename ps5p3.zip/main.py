counter = 0

response =  input("Want to Average your Test Scores? Yes or No")

while response == "Yes":
  counter = counter + 1
  lastname = input("Enter Student Last Name")
  test1 = float(input("Enter Test Score 1"))
  test2 = float(input("Enter Test Score 2"))
  avg = (test1 + test2)/2
  print("Student:    ", lastname)
  print("Average of Test 1 and Test 2:    ", avg)
  print("Number of Students Entered:      ", counter)
  response =  input("Want to Average your Test Scores? Yes or No")
