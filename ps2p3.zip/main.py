#input
L1 = float(input("Enter length"))
W1 = float(input("Enter width"))

#process phase
A = L1 * W1
P = 2 * L1 + 2 * W1

#output
print("The area is",A)
print("The perimeter is",P)