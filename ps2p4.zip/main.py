#comment input
L1 = (input("Enter a lastname"))
C1 = float(input("Enter credit hours taken"))

#process phase
T= C1 * 250 + 100

#output
print("The total of tution for" , L1, T) 