#comment input
L1 = (input("Enter a lastname"))
H1 = float(input("Enter hours worked"))
P1 = float(input("Enter pay rate"))

#process phase
S=H1 * P1

#output
print("The gross pay for" , L1, S) 