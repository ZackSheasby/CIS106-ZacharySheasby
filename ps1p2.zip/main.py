#comment input
lastname = (input("Enter lastname"))
E1 = float(input("Enter a number"))
E2 = float(input("Enter another number"))

#process phase
S = E1 + E2
A = S / 2

#output
print("The sum is", S)
print ("The average for" ,lastname , A)