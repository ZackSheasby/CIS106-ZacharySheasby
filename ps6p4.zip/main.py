f = open("data1.txt", "r")

c = 0
sm = 0.0
totalq = 0.0
item = str(f.readline().rstrip('\n'))

while item != "":
  qty = float(f.readline().rstrip('\n'))
  price = float(f.readline())

  totalq = totalq + qty
  extprice = qty * price
  c = c + 1
  sm = sm + extprice
  avgorder = totalq / c

  print("Item:", item)
  print("Quantity:",qty)
  print("Price:  ", price)
  print("Extended Price:  ",extprice)
  print("    ")

  item = str(f.readline().rstrip('\n'))

f.close()  

print("Sum of all Extended Prices:  ", sm)
print("Number of Orders:", c)
print("Average Order:  ", avgorder  )


