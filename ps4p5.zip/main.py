
lastname = input("Enter Lastname")
sal = int(input("Enter Salary"))
joblvl = int(input("Enter Job Level"))

if joblvl > 10:
  rate = .25
elif joblvl > 5:
  rate = .20
elif joblvl < 5:
  rate = .10

bonus = sal * rate

print("Lastname:    ",lastname)
print("Bonus:     ",bonus)

