app=input("Enter name of appliance")
cost=float(input("Enter cost of appliance"))

if cost >=1000:
  up= cost * 0.10
else:
  up= cost * 0.05  

war= up

total= cost + up

print("The appliance is", app)
print("The cost of the warrantee is ", war)
print("The total is", total)