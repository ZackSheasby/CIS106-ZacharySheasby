#comment input
M1 = float(input("Enter the amount for the meal"))
T1 = float(input("Enter 0.15 for the tip"))

#process phase
S= M1 * T1

#Output 
print ("The tip should be", S)